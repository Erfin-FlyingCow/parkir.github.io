<?php
session_start();

require('conn.php');

$error = '';


if (isset($_POST['submit'])) {
    // ... (bagian validasi CSRF token dan pengolahan input username dan password)
    if (!empty(trim($username)) && !empty(trim($password))) {
        $query = "SELECT * FROM pegawai WHERE username = '$username'";
        $result = mysqli_query($conn, $query);
        $rows = mysqli_num_rows($result);

        if ($rows != 0) {
            $hash = mysqli_fetch_assoc($result)['password'];
            if (password_verify($password, $hash)) {
                if ($_SESSION["code"] != $_POST["kodecaptcha"]) {
                    $error = "Kode CAPTCHA anda salah";
                } else {
                    $_SESSION['username'] = $username;
                    header('Location: index.php');
                    exit; // Penting: setelah header(), pastikan untuk keluar dari skrip dengan exit atau die
                }
            } else {
                $error = 'Password yang dimasukkan salah.';
            }
        } else {
            $error = 'Username tidak ditemukan.';
        }
    } else {
        $error = 'Username dan password tidak boleh kosong.';
    }
} else {
    die('Akses ditolak!');
}


// Membuat token CSRF
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>

<body>
    <form action="login.php" method="post">
        <table>
            <tr>
                <td><label for="username">Username</label></td>
                <td><input type="text" id="username" name="username" placeholder="Masukan Username"> </td>
            </tr>
            <tr>
                <td><label for="inputpassword">Password</label></td>
                <td><input type="password" id="inputpassword" name="password" placeholder="Password"></td>
            </tr>
            <tr>
                <td>Captcha</td>
                <td><img src="captcha.php" alt="gambar" /> </td>
            </tr>
            <tr>
                <td>Isikan captcha </td>
                <td><input name="kodecaptcha" value="" maxlength="5" /></td>
            </tr>
        </table>
        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
        <input type="submit" name="submit" value="Login">
    </form>

    <?php
    if (!empty($error)) {
        echo '<p style="color: red;">' . $error . '</p>';
    }
    ?>

    <p>Belum punya akun? <a href="register.php">Registrasi</a></p>
</body>

</html>