<?php
session_start();
require('conn.php');

$error = '';


if (isset($_POST['submit'])) {
    $username = stripslashes($_POST['username']);
    $username = mysqli_real_escape_string($conn, $username);
    $password = stripslashes($_POST['password']);
    $password = mysqli_real_escape_string($conn, $password);
    $repass = stripslashes($_POST['repassword']);
    $repass = mysqli_real_escape_string($conn, $repass);

    if (!empty(trim($username)) && !empty(trim($password)) && !empty(trim($repass))) {
        if ($password == $repass) {
            if (cek_nama($username, $conn) == 0) {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $query = "INSERT INTO pegawai (username, password) VALUES ('$username','$hashed_password')";
                $result = mysqli_query($conn, $query);

                if ($result) {
                    $_SESSION['username'] = $username;

                } else {
                    $error = "Register user gagal";
                }
            } else {
                $error = "Username sudah terdaftar";
            }
        } else {
            $error = "Password tidak sama";
        }
    } else {
        $error = "Data tidak boleh kosong";
    }
}

function cek_nama($username, $conn)
{
    $nama = mysqli_real_escape_string($conn, $username);
    $query = "SELECT * FROM pegawai WHERE username = '$nama'";
    $result = mysqli_query($conn, $query);

    return mysqli_num_rows($result);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
</head>

<body>
    <form action="register.php" method="post">
        <h4>Sign Up</h4>
        <?php
        if ($error != '') {
            echo '<div role="alert">' . $error . '</div>';
        }
        ?>
        <table>
            <tr>
                <td><label for="username">Username</label></td>
                <td><input type="text" id="username" name="username" placeholder="Masukan Username"></td>
            </tr>
            <tr>
                <td><label for="inputpassword">Password</label></td>
                <td><input type="password" id="inputpassword" name="password" placeholder="Password"></td>
            </tr>
            <tr>
                <td><label for="inputrepassword">Re-Password</label></td>
                <td><input type="password" id="inputrepassword" name="repassword" placeholder="Re-Password"></td>
            </tr>
            <tr>
                <td><button type="submit" name="submit">Register</button></td>
            </tr>
            <tr>
                <td>
                    <p>Sudah Punya akun? <a href="login.php">Login</a></p>
                </td>
            </tr>
        </table>
    </form>
</body>

</html>