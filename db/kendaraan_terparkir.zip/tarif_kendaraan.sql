-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2024 at 02:27 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uas`
--

-- --------------------------------------------------------

--
-- Table structure for table `tarif_kendaraan`
--

CREATE TABLE `tarif_kendaraan` (
  `id_kendaraan` varchar(3) NOT NULL,
  `nama_kendaraan` varchar(30) NOT NULL,
  `tarif_per_jam` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tarif_kendaraan`
--

INSERT INTO `tarif_kendaraan` (`id_kendaraan`, `nama_kendaraan`, `tarif_per_jam`) VALUES
('001', 'Motor', 2000),
('002', 'Mobil', 5000),
('003', 'Sepeda', 1000),
('004', 'Truk Kecil', 8000),
('005', 'Truk Besar', 12000),
('006', 'Bus Sedang', 7000),
('007', 'Bus Besar', 10000),
('008', 'Motor Besar', 5000),
('009', 'Minibus', 6000),
('010', 'Van', 5500);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
