-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2024 at 02:27 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uas`
--

-- --------------------------------------------------------

--
-- Table structure for table `kendaraan_terparkir`
--

CREATE TABLE `kendaraan_terparkir` (
  `id_parkir` int(5) NOT NULL,
  `id_kendaraan` varchar(20) NOT NULL,
  `plat` varchar(20) NOT NULL,
  `waktu_masuk` datetime NOT NULL,
  `waktu_keluar` datetime DEFAULT NULL,
  `tarif_total` bigint(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kendaraan_terparkir`
--

INSERT INTO `kendaraan_terparkir` (`id_parkir`, `id_kendaraan`, `plat`, `waktu_masuk`, `waktu_keluar`, `tarif_total`) VALUES
(1, '101', 'B 1234 CD', '2023-01-01 08:00:00', '2023-01-01 10:30:00', 6000),
(2, '102', 'D 5678 EF', '2023-01-01 09:15:00', '2023-01-01 11:45:00', 6000),
(3, '103', 'F 9101 GH', '2023-01-01 10:30:00', '2023-01-01 12:45:00', 6000),
(4, '104', 'J 1122 KL', '2023-01-01 11:45:00', '2023-01-01 13:30:00', 4000),
(5, '105', 'M 3344 NP', '2023-01-01 13:00:00', '2023-01-01 15:15:00', 6000),
(6, '106', 'P 5566 RS', '2023-01-01 14:15:00', '2023-01-01 16:45:00', 32000),
(7, '107', 'S 7788 UV', '2023-01-01 15:30:00', '2023-01-01 18:00:00', 27000),
(8, '108', 'V 9900 WX', '2023-01-01 16:45:00', '2023-01-01 19:15:00', 31000),
(9, '109', 'Y 1122 ZZ', '2023-01-01 18:00:00', '2023-01-01 20:30:00', 29000),
(10, '110', 'AA 3344 BB', '2023-01-01 19:15:00', '2023-01-01 21:45:00', 26000),
(11, '009', 'B 1989 HQ', '2024-01-06 10:18:03', '2024-01-06 19:55:06', 20000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kendaraan_terparkir`
--
ALTER TABLE `kendaraan_terparkir`
  ADD PRIMARY KEY (`id_parkir`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kendaraan_terparkir`
--
ALTER TABLE `kendaraan_terparkir`
  MODIFY `id_parkir` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
